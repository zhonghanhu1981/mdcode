program argon_md_rdf
    implicit none

    ! ---- System: 108 atoms on FCC lattice, rho = 0.8 ----
    integer, parameter :: N = 108
    integer, parameter :: NCELL = 3
    real(8), parameter :: RHO = 0.8d0
    real(8), parameter :: BOXL = (dble(N)/RHO)**(1.0d0/3.0d0)   ! ~5.12

    integer, parameter :: NSTEP = 40000
    integer, parameter :: NEQUIL = 10000
    integer, parameter :: NPRINT = 1000
    integer, parameter :: NRDF = 200
    real(8), parameter :: DT = 0.004d0
    real(8), parameter :: RCUT = 2.5d0
    real(8), parameter :: TEMP = 1.6d0
    real(8), parameter :: EPSILON = 1.0d0, SIGMA = 1.0d0, MASS = 1.0d0

    ! ---- Thermostat parameters ----
    real(8), parameter :: TAU_T = 0.5d0     ! Berendsen coupling time (reduced units)
    logical, parameter :: USE_NVT = .true.  ! .true. = NVT throughout, .false. = NVE after equilibration

    real(8) :: rx(N), ry(N), rz(N)
    real(8) :: vx(N), vy(N), vz(N)
    real(8) :: fx(N), fy(N), fz(N)
    real(8) :: pe, ke, temp_inst
    real(8) :: gr(NRDF), gr_hist(NRDF), r_bin(NRDF)
    real(8) :: dr
    integer :: n_sample_rdf, i, step
    real(8) :: sum_v2, vcm_x, vcm_y, vcm_z

    call init_random_seed()
    call init_fcc(rx, ry, rz, BOXL, N, NCELL)
    call init_velocities(vx, vy, vz, N, TEMP)

    vcm_x = sum(vx)/dble(N); vcm_y = sum(vy)/dble(N); vcm_z = sum(vz)/dble(N)
    vx = vx - vcm_x; vy = vy - vcm_y; vz = vz - vcm_z

    call compute_forces(rx, ry, rz, fx, fy, fz, pe, N, BOXL, RCUT, EPSILON, SIGMA)

    gr_hist = 0.0d0
    n_sample_rdf = 0
    dr = RCUT / dble(NRDF)
    do i = 1, NRDF
        r_bin(i) = (dble(i) - 0.5d0) * dr
    end do

    open(unit=10, file='argon_md.log', status='replace')
    write(10,*) '# Step  Temp  PotEng  KinEng  TotEng  lambda'

    do step = 1, NSTEP
        ! --- Velocity-Verlet step ---
        do i = 1, N
            vx(i) = vx(i) + 0.5d0 * DT * fx(i) / MASS
            vy(i) = vy(i) + 0.5d0 * DT * fy(i) / MASS
            vz(i) = vz(i) + 0.5d0 * DT * fz(i) / MASS
        end do
        do i = 1, N
            rx(i) = rx(i) + DT * vx(i)
            ry(i) = ry(i) + DT * vy(i)
            rz(i) = rz(i) + DT * vz(i)
        end do
        do i = 1, N
            rx(i) = rx(i) - BOXL * anint(rx(i)/BOXL)
            ry(i) = ry(i) - BOXL * anint(ry(i)/BOXL)
            rz(i) = rz(i) - BOXL * anint(rz(i)/BOXL)
        end do
        call compute_forces(rx, ry, rz, fx, fy, fz, pe, N, BOXL, RCUT, EPSILON, SIGMA)
        do i = 1, N
            vx(i) = vx(i) + 0.5d0 * DT * fx(i) / MASS
            vy(i) = vy(i) + 0.5d0 * DT * fy(i) / MASS
            vz(i) = vz(i) + 0.5d0 * DT * fz(i) / MASS
        end do

        ! --- Thermostat: Berendsen rescaling during equilibration ---
        !     (and throughout if USE_NVT = .true.)
        if ((step <= NEQUIL) .or. USE_NVT) then
            call berendsen_thermostat(vx, vy, vz, N, MASS, TEMP, DT, TAU_T)
        end if

        ! --- Diagnostics ---
        sum_v2 = 0.0d0
        do i = 1, N
            sum_v2 = sum_v2 + vx(i)**2 + vy(i)**2 + vz(i)**2
        end do
        ke = 0.5d0 * MASS * sum_v2
        temp_inst = 2.0d0 * ke / (3.0d0 * dble(N))

        ! --- RDF sampling (after equilibration) ---
        if (step > NEQUIL) then
            call accumulate_rdf(rx, ry, rz, gr_hist, N, BOXL, RCUT, NRDF, dr)
            n_sample_rdf = n_sample_rdf + 1
        end if

        if (mod(step, NPRINT) == 0) then
            write(10,'(I8,5F14.6)') step, temp_inst, pe, ke, pe+ke, &
                sqrt(TEMP/max(temp_inst, 1.0d-12))
            write(*,'(A,I6,A,F9.4,A,F12.4,A,I9)') 'Step ', step, &
           &  '  T = ', temp_inst, '  E_tot = ', pe+ke, '  n_rdf = ', n_sample_rdf
        end if
    end do
    close(10)

    call normalize_rdf(gr_hist, gr, r_bin, N, BOXL, RCUT, NRDF, dr, n_sample_rdf)

    open(unit=11, file='rdf.dat', status='replace')
    write(11,*) '# r  g(r)   [N=', N, '  BOXL=', BOXL, '  rho=', RHO, ']'
    do i = 1, NRDF
        write(11,'(2F16.8)') r_bin(i), gr(i)
    end do
    close(11)

    block
        real(8) :: gsum
        integer :: icount
        gsum = 0.0d0; icount = 0
        do i = 1, NRDF
            if (r_bin(i) > 1.5d0) then
                gsum = gsum + gr(i); icount = icount + 1
            end if
        end do
        write(*,'(A,F8.4)') '  <g(r)> for r>1.5 = ', gsum/dble(icount)
        write(*,'(A,I6)')   '  RDF sampling frames = ', n_sample_rdf
    end block
    write(*,*) 'Done. See rdf.dat'

contains

    !------------------------------------------------------------------
    !  Berendsen velocity-rescaling thermostat
    !     lambda = sqrt( 1 + (DT/TAU)*(T0/T - 1) )
    !     v_i <- lambda * v_i
    !  T0 : target temperature (reduced units, k_B = 1)
    !  TAU: coupling time; TAU -> 0 gives hard rescaling (lambda = sqrt(T0/T))
    !------------------------------------------------------------------
    subroutine berendsen_thermostat(vx, vy, vz, n, mass, t0, dt, tau)
        integer, intent(in) :: n
        real(8), intent(in) :: mass, t0, dt, tau
        real(8), intent(inout) :: vx(n), vy(n), vz(n)
        real(8) :: ke, t_inst, lambda, sum_v2
        integer :: i

        sum_v2 = 0.0d0
        do i = 1, n
            sum_v2 = sum_v2 + vx(i)**2 + vy(i)**2 + vz(i)**2
        end do
        if (sum_v2 < 1.0d-30) return          ! nothing to scale
        ke     = 0.5d0 * mass * sum_v2
        t_inst = 2.0d0 * ke / (3.0d0 * dble(n))
        if (t_inst < 1.0d-30) return

        if (tau > 1.0d-12) then
            lambda = sqrt(1.0d0 + (dt/tau) * (t0/t_inst - 1.0d0))
        else
            lambda = sqrt(t0 / t_inst)        ! hard rescaling limit
        end if
        lambda = max(lambda, 0.0d0)

        do i = 1, n
            vx(i) = lambda * vx(i)
            vy(i) = lambda * vy(i)
            vz(i) = lambda * vz(i)
        end do
    end subroutine

    subroutine init_random_seed()
        integer :: i, n, clock
        integer, allocatable :: seed(:)
        call random_seed(size = n)
        allocate(seed(n))
        call system_clock(count=clock)
        seed = clock + 37 * (/ (i - 1, i = 1, n) /)
        call random_seed(put = seed)
        deallocate(seed)
    end subroutine

    subroutine init_fcc(rx, ry, rz, boxl, n, ncell)
        integer, intent(in) :: n, ncell
        real(8), intent(in) :: boxl
        real(8), intent(out) :: rx(n), ry(n), rz(n)
        integer :: ix, iy, iz, b, i
        real(8) :: a
        real(8), parameter :: bx(4) = [0.0d0, 0.5d0, 0.5d0, 0.0d0]
        real(8), parameter :: by(4) = [0.0d0, 0.5d0, 0.0d0, 0.5d0]
        real(8), parameter :: bz(4) = [0.0d0, 0.0d0, 0.5d0, 0.5d0]
        a = boxl / dble(ncell)
        i = 0
        do ix = 0, ncell-1
            do iy = 0, ncell-1
                do iz = 0, ncell-1
                    do b = 1, 4
                        i = i + 1
                        rx(i) = (dble(ix) + bx(b)) * a
                        ry(i) = (dble(iy) + by(b)) * a
                        rz(i) = (dble(iz) + bz(b)) * a
                    end do
                end do
            end do
        end do
    end subroutine

    subroutine init_velocities(vx, vy, vz, n, temp)
        integer, intent(in) :: n
        real(8), intent(in) :: temp
        real(8), intent(out) :: vx(n), vy(n), vz(n)
        integer :: i
        real(8) :: g1, g2, sv
        sv = sqrt(temp)
        do i = 1, n
            call gaussian_random(g1); call gaussian_random(g2); vx(i) = g1*sv
            call gaussian_random(g1); call gaussian_random(g2); vy(i) = g2*sv
            call gaussian_random(g1); call gaussian_random(g2); vz(i) = g1*sv
        end do
    end subroutine

    subroutine gaussian_random(g)
        real(8), intent(out) :: g
        real(8) :: u1, u2, r
        call random_number(u1); call random_number(u2)
        r = sqrt(-2.0d0 * log(u1))
        g = r * cos(2.0d0 * 3.141592653589793d0 * u2)
    end subroutine

    subroutine compute_forces(rx, ry, rz, fx, fy, fz, pe, n, boxl, rcut, eps, sig)
        integer, intent(in) :: n
        real(8), intent(in) :: rx(n), ry(n), rz(n), boxl, rcut, eps, sig
        real(8), intent(out) :: fx(n), fy(n), fz(n), pe
        integer :: i, j
        real(8) :: rxij, ryij, rzij, rij2, rij, r6, r12, fmag, rcut2
        fx = 0.0d0; fy = 0.0d0; fz = 0.0d0; pe = 0.0d0
        rcut2 = rcut * rcut
        do i = 1, n - 1
            do j = i + 1, n
                rxij = rx(i) - rx(j); ryij = ry(i) - ry(j); rzij = rz(i) - rz(j)
                rxij = rxij - boxl * anint(rxij / boxl)
                ryij = ryij - boxl * anint(ryij / boxl)
                rzij = rzij - boxl * anint(rzij / boxl)
                rij2 = rxij**2 + ryij**2 + rzij**2
                if (rij2 < rcut2) then
                    rij = sqrt(rij2)
                    r6  = (sig / rij)**6
                    r12 = r6 * r6
                    pe = pe + 4.0d0 * eps * (r12 - r6)
                    fmag = 24.0d0 * eps * (2.0d0 * r12 - r6) / rij2
                    fx(i) = fx(i) + fmag * rxij
                    fy(i) = fy(i) + fmag * ryij
                    fz(i) = fz(i) + fmag * rzij
                    fx(j) = fx(j) - fmag * rxij
                    fy(j) = fy(j) - fmag * ryij
                    fz(j) = fz(j) - fmag * rzij
                end if
            end do
        end do
    end subroutine

    subroutine accumulate_rdf(rx, ry, rz, hist, n, boxl, rcut, nbins, dr)
        integer, intent(in) :: n, nbins
        real(8), intent(in) :: rx(n), ry(n), rz(n), boxl, rcut, dr
        real(8), intent(inout) :: hist(nbins)
        integer :: i, j, ibin
        real(8) :: rxij, ryij, rzij, rij2, rij
        do i = 1, n - 1
            do j = i + 1, n
                rxij = rx(i) - rx(j); ryij = ry(i) - ry(j); rzij = rz(i) - rz(j)
                rxij = rxij - boxl * anint(rxij / boxl)
                ryij = ryij - boxl * anint(ryij / boxl)
                rzij = rzij - boxl * anint(rzij / boxl)
                rij2 = rxij**2 + ryij**2 + rzij**2
                if (rij2 < rcut*rcut) then
                    rij = sqrt(rij2)
                    ibin = int(rij / dr) + 1
                    if (ibin >= 1 .and. ibin <= nbins) hist(ibin) = hist(ibin) + 2.0d0
                end if
            end do
        end do
    end subroutine

    subroutine normalize_rdf(hist, gr, r_bin, n, boxl, rcut, nbins, dr, nframes)
        integer, intent(in) :: n, nbins, nframes
        real(8), intent(in) :: hist(nbins), r_bin(nbins), boxl, rcut, dr
        real(8), intent(out) :: gr(nbins)
        integer :: i
        real(8) :: rho, vol_shell, norm
        rho = dble(n) / boxl**3
        do i = 1, nbins
            vol_shell = 4.0d0 * 3.141592653589793d0 * r_bin(i)**2 * dr
            norm = dble(nframes) * dble(n) * rho * vol_shell
            if (norm > 0.0d0) then
                gr(i) = hist(i) / norm
            else
                gr(i) = 0.0d0
            end if
        end do
    end subroutine

end program argon_md_rdf
