! Molecular Dynamics Simulation of Liquid Argon (N=128)
! with Radial Distribution Function (RDF) calculation
program argon_md_rdf
    implicit none

    ! Simulation Parameters
    integer, parameter :: N = 128           ! Number of atoms
    integer, parameter :: NSTEP = 20000     ! Total number of time steps
    integer, parameter :: NEQUIL = 5000     ! Equilibration steps (not sampled)
    integer, parameter :: NPRINT = 500      ! Output frequency
    integer, parameter :: NRDF = 200        ! Number of RDF bins
    real(8), parameter :: DT = 0.005d0      ! Time step (reduced units)
    real(8), parameter :: RCUT = 2.5d0      ! Cutoff radius (in sigma)
    real(8), parameter :: BOXL = 7.14d0     ! Box length for density ~0.8
    real(8), parameter :: TEMP = 0.8d0      ! Target temperature
    real(8), parameter :: EPSILON = 1.0d0
    real(8), parameter :: SIGMA = 1.0d0
    real(8), parameter :: MASS = 1.0d0

    ! Arrays
    real(8) :: rx(N), ry(N), rz(N)
    real(8) :: vx(N), vy(N), vz(N)
    real(8) :: fx(N), fy(N), fz(N)
    real(8) :: pe, ke, temp_inst

    ! RDF arrays
    real(8) :: gr(NRDF), gr_hist(NRDF), r_bin(NRDF)
    real(8) :: dr
    integer  :: n_sample_rdf

    ! Local variables
    integer :: i, step
    real(8) :: sum_v2, vcm_x, vcm_y, vcm_z

    ! Initialize random seed
    call init_random_seed()

    ! Initialize system
    call initialize_system(rx, ry, rz, vx, vy, vz, BOXL, N, TEMP)

    ! Remove center of mass velocity
    vcm_x = sum(vx)/dble(N)
    vcm_y = sum(vy)/dble(N)
    vcm_z = sum(vz)/dble(N)
    vx = vx - vcm_x
    vy = vy - vcm_y
    vz = vz - vcm_z

    ! Initial force
    call compute_forces(rx, ry, rz, fx, fy, fz, pe, N, BOXL, RCUT, EPSILON, SIGMA)

    ! Zero RDF accumulator
    gr_hist = 0.0d0
    n_sample_rdf = 0
    dr = RCUT / dble(NRDF)

    ! Bin centers
    do i = 1, NRDF
        r_bin(i) = (dble(i) - 0.5d0) * dr
    end do

    ! Open output files
    open(unit=10, file='argon_md.log', status='replace')
    write(10,*) '# Step  Temp  PotEng  KinEng  TotEng'

    ! Main MD Loop
    do step = 1, NSTEP
        ! Velocity-Verlet: half-kick
        do i = 1, N
            vx(i) = vx(i) + 0.5d0 * DT * fx(i) / MASS
            vy(i) = vy(i) + 0.5d0 * DT * fy(i) / MASS
            vz(i) = vz(i) + 0.5d0 * DT * fz(i) / MASS
        end do

        ! Drift
        do i = 1, N
            rx(i) = rx(i) + DT * vx(i)
            ry(i) = ry(i) + DT * vy(i)
            rz(i) = rz(i) + DT * vz(i)
        end do

        ! PBC
        do i = 1, N
            rx(i) = rx(i) - BOXL * anint(rx(i)/BOXL)
            ry(i) = ry(i) - BOXL * anint(ry(i)/BOXL)
            rz(i) = rz(i) - BOXL * anint(rz(i)/BOXL)
        end do

        ! New forces
        call compute_forces(rx, ry, rz, fx, fy, fz, pe, N, BOXL, RCUT, EPSILON, SIGMA)

        ! Second half-kick
        do i = 1, N
            vx(i) = vx(i) + 0.5d0 * DT * fx(i) / MASS
            vy(i) = vy(i) + 0.5d0 * DT * fy(i) / MASS
            vz(i) = vz(i) + 0.5d0 * DT * fz(i) / MASS
        end do

        ! Kinetic energy & temperature
        sum_v2 = 0.0d0
        do i = 1, N
            sum_v2 = sum_v2 + vx(i)**2 + vy(i)**2 + vz(i)**2
        end do
        ke = 0.5d0 * MASS * sum_v2
        temp_inst = 2.0d0 * ke / (3.0d0 * dble(N))

        ! Accumulate RDF after equilibration
        if (step > NEQUIL) then
            call accumulate_rdf(rx, ry, rz, gr_hist, N, BOXL, RCUT, NRDF, dr)
            n_sample_rdf = n_sample_rdf + 1
        end if

        ! Logging
        if (mod(step, NPRINT) == 0) then
            write(10,'(I8,4F14.6)') step, temp_inst, pe, ke, pe+ke
            write(*,'(A,I6,A,F10.4,A,F10.4)') 'Step ', step, &
                '  T = ', temp_inst, '  E_tot = ', pe+ke
        end if
    end do

    close(10)

    ! Normalize RDF and write output
    call normalize_rdf(gr_hist, gr, r_bin, N, BOXL, RCUT, NRDF, dr, n_sample_rdf)

    open(unit=11, file='rdf.dat', status='replace')
    write(11,*) '# r  g(r)'
    do i = 1, NRDF
        write(11,'(2F16.8)') r_bin(i), gr(i)
    end do
    close(11)

    write(*,*) 'Simulation finished.'
    write(*,*) 'RDF written to rdf.dat (averaged over ', n_sample_rdf, ' configurations)'

contains

    subroutine init_random_seed()
        integer :: i, n, clock
        integer, allocatable :: seed(:)
        call random_seed(size = n)
        allocate(seed(n))
        call system_clock(count=clock)
        seed = clock + 37 * (/ (i - 1, i = 1, n) /)
        call random_seed(put = seed)
        deallocate(seed)
    end subroutine

    subroutine initialize_system(rx, ry, rz, vx, vy, vz, boxl, n, temp)
        integer, intent(in) :: n
        real(8), intent(in) :: boxl, temp
        real(8), intent(out) :: rx(n), ry(n), rz(n), vx(n), vy(n), vz(n)
        integer :: i, ix, iy, iz
        real(8) :: g1, g2, sigma_v

        i = 0
        outer: do ix = 1, 6
            do iy = 1, 6
                do iz = 1, 6
                    i = i + 1
                    if (i > n) exit outer
                    rx(i) = (dble(ix) - 0.5d0) * boxl / 6.0d0
                    ry(i) = (dble(iy) - 0.5d0) * boxl / 6.0d0
                    rz(i) = (dble(iz) - 0.5d0) * boxl / 6.0d0
                end do
            end do
        end do outer

        sigma_v = sqrt(temp)
        do i = 1, n
            call gaussian_random(g1)
            call gaussian_random(g2)
            vx(i) = g1 * sigma_v
            vy(i) = g2 * sigma_v
            call gaussian_random(g1)
            call gaussian_random(g2)
            vz(i) = g1 * sigma_v
        end do
    end subroutine

    subroutine gaussian_random(g)
        real(8), intent(out) :: g
        real(8) :: u1, u2, r
        call random_number(u1)
        call random_number(u2)
        r = sqrt(-2.0d0 * log(u1))
        g = r * cos(2.0d0 * 3.141592653589793d0 * u2)
    end subroutine

    subroutine compute_forces(rx, ry, rz, fx, fy, fz, pe, n, boxl, rcut, eps, sig)
        integer, intent(in) :: n
        real(8), intent(in) :: rx(n), ry(n), rz(n), boxl, rcut, eps, sig
        real(8), intent(out) :: fx(n), fy(n), fz(n), pe
        integer :: i, j
        real(8) :: rxij, ryij, rzij, rij2, rij, r6, r12, fmag, rcut2

        fx = 0.0d0; fy = 0.0d0; fz = 0.0d0
        pe = 0.0d0
        rcut2 = rcut * rcut

        do i = 1, n - 1
            do j = i + 1, n
                rxij = rx(i) - rx(j)
                ryij = ry(i) - ry(j)
                rzij = rz(i) - rz(j)
                rxij = rxij - boxl * anint(rxij / boxl)
                ryij = ryij - boxl * anint(ryij / boxl)
                rzij = rzij - boxl * anint(rzij / boxl)
                rij2 = rxij**2 + ryij**2 + rzij**2

                if (rij2 < rcut2) then
                    rij = sqrt(rij2)
                    r6  = (sig / rij)**6
                    r12 = r6 * r6
                    pe = pe + 4.0d0 * eps * (r12 - r6)
                    ! Shift potential to zero at cutoff for smoother energy conservation
                    ! (optional: uncomment the following line to shift)
                    ! pe = pe + 4.0d0 * eps * (r12 - r6) &
                    !        - 4.0d0 * eps * ((sig/rcut)**12 - (sig/rcut)**6)

                    fmag = 24.0d0 * eps * (2.0d0 * r12 - r6) / rij2

                    fx(i) = fx(i) + fmag * rxij
                    fy(i) = fy(i) + fmag * ryij
                    fz(i) = fz(i) + fmag * rzij
                    fx(j) = fx(j) - fmag * rxij
                    fy(j) = fy(j) - fmag * ryij
                    fz(j) = fz(j) - fmag * rzij
                end if
            end do
        end do
    end subroutine

    ! Accumulate pair distances into histogram
    subroutine accumulate_rdf(rx, ry, rz, hist, n, boxl, rcut, nbins, dr)
        integer, intent(in) :: n, nbins
        real(8), intent(in) :: rx(n), ry(n), rz(n), boxl, rcut, dr
        real(8), intent(inout) :: hist(nbins)
        integer :: i, j, ibin
        real(8) :: rxij, ryij, rzij, rij2, rij

        do i = 1, n - 1
            do j = i + 1, n
                rxij = rx(i) - rx(j)
                ryij = ry(i) - ry(j)
                rzij = rz(i) - rz(j)
                rxij = rxij - boxl * anint(rxij / boxl)
                ryij = ryij - boxl * anint(ryij / boxl)
                rzij = rzij - boxl * anint(rzij / boxl)
                rij2 = rxij**2 + ryij**2 + rzij**2
                if (rij2 < rcut*rcut) then
                    rij = sqrt(rij2)
                    ibin = int(rij / dr) + 1
                    if (ibin >= 1 .and. ibin <= nbins) then
                        hist(ibin) = hist(ibin) + 2.0d0  ! count both (i,j) and (j,i)
                    end if
                end if
            end do
        end do
    end subroutine

    ! Normalize RDF: g(r) = hist / (N * rho * 4*pi*r^2*dr * n_frames / 2)
    subroutine normalize_rdf(hist, gr, r_bin, n, boxl, rcut, nbins, dr, nframes)
        integer, intent(in) :: n, nbins, nframes
        real(8), intent(in) :: hist(nbins), r_bin(nbins), boxl, rcut, dr
        real(8), intent(out) :: gr(nbins)
        integer :: i
        real(8) :: rho, vol_shell, norm

        rho = dble(n) / boxl**3
        do i = 1, nbins
            vol_shell = 4.0d0 * 3.141592653589793d0 * r_bin(i)**2 * dr
            ! hist counts ordered pairs (each pair counted twice), so divide by 2
            ! Norm: each frame contributes N * rho * shell volume / 2 ordered pair "expected"
            norm = dble(nframes) * dble(n) * rho * vol_shell
            if (norm > 0.0d0) then
                gr(i) = hist(i) / norm
            else
                gr(i) = 0.0d0
            end if
        end do
    end subroutine

end program argon_md_rdf
