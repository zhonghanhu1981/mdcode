! Function to compute the cross product of two 3D vectors
function cross_product(a, b) result(c)
    real(8), intent(in) :: a(3), b(3)
    real(8) :: c(3)
    c(1) = a(2)*b(3) - a(3)*b(2)
    c(2) = a(3)*b(1) - a(1)*b(3)
    c(3) = a(1)*b(2) - a(2)*b(1)
end function cross_product

! Function to compute the Euclidean norm of a 3D vector
function norm(a) result(n)
    real(8), intent(in) :: a(3)
    real(8) :: n
    n = sqrt(dot_product(a, a))
end function norm

subroutine tri_e3dtf(a1,a2,a3,x,y,z,nu_total)
    implicit none
    !
    ! the formula see J.Phys.Chem.Letts.   He_Hu2026
    ! Appendix Eqs(A1) to (A4)
    ! date> Jun 23, 2026
    !
    real(8), parameter :: pi = 3.14159265358979323846d0

    ! Inputs/output
    real(8) :: a1(3), a2(3), a3(3)
    real(8) :: x, y, z
    
    real(8) :: nu_total
    ! external function
    !real(8),dimension(1:3),external:: cross_product
    real(8),external:: norm
 
    ! Derived quantities
    real(8) :: b1(3), b2(3), b3(3)
    real(8) :: V, alpha
    
    ! Summation variables
    real(8) :: r(3)
    real(8) :: nu_R, nu_F
    real(8) :: R_cut, K_cut
    integer :: n1, n2, n3, k1, k2, k3
    integer :: n_max, k_max
    real(8) :: n_vec(3), k_vec(3), r_n(3)
    real(8) :: r_n_norm, n_norm, k_norm, k_dot_r, scal
    real(8) :: tmp1(3), tmp2(3), tmp3(3)
    
    ! Tolerance for zero-check     exp(-36) = 10^-16 erfc(6) = 10^-16
    real(8), parameter :: eps = 1.0d-16, exl = 36.0d0

    !===========================================================================
    ! 1. DEFINE INPUTS (Replace these with your actual triclinic lattice data)
    !===========================================================================
    ! Example: Simple cubic lattice with lattice constant a = 1.0
    !a1 = (/ 0.0d0, 1.0d0, 1.0d0 /)
    !a2 = (/ 1.0d0, 0.0d0, 1.0d0 /)
    !a3 = (/ 1.0d0, 1.0d0, 0.0d0 /)
    
    ! Example: Field point r (must NOT be exactly a lattice vector to avoid 1/0 divergence)
    r(1) = x; r(2) = y; r(3) = z
    !r = (/ 1.0d0, 0.0d0, 0.0d0 /); scal = 1.0d0    ! NaCl
    !r = (/ 0.5d0, 0.5d0, 0.5d0 /); scal = sqrt(3.0d0)*0.5d0  ! ZnS
    
    ! Ewald splitting parameter (as suggested)
    alpha = sqrt(pi) !            10^-14
    !alpha = 0.1d0    accuracy of 10^-13
    !alpha = 10.d0                10^-13
    !alpha = 2.d0                 10^-14
    
    ! Cutoff radii for real and Fourier space (adjust for desired accuracy)
    R_cut = 30.0d0   ! not used
    K_cut = 30.0d0   ! not used

    !===========================================================================
    ! 2. COMPUTE VOLUME AND RECIPROCAL LATTICE VECTORS
    !===========================================================================
    call crs_vdb(a1,a2,tmp1)
    !V = dot_product(cross_product(a1, a2), a3)
    V = dot_product(tmp1, a3)
    
    call crs_vdb(a2,a3,tmp1);call crs_vdb(a3,a1,tmp2);call crs_vdb(a1,a2,tmp3)
    b1 = (2.0d0 * pi / V) * tmp1
    b2 = (2.0d0 * pi / V) * tmp2
    b3 = (2.0d0 * pi / V) * tmp3

    ! Determine maximum integer indices needed to cover the spherical cutoffs
    !n_max = ceiling(R_cut / min(norm(a1), norm(a2), norm(a3))) + 2
    !k_max = ceiling(K_cut / min(norm(b1), norm(b2), norm(b3))) + 2
    n_max = int(sqrt(exl)/alpha/min(norm(a1), norm(a2), norm(a3))) + 2
    k_max = int(sqrt(4.0d0*alpha**2*exl)/min(norm(b1), norm(b2), norm(b3))) + 2

    !===========================================================================
    ! 3. REAL-SPACE SUMMATION (nu_R)
    !===========================================================================
    nu_R = 0.0d0
    
    do n1 = -n_max, n_max
        do n2 = -n_max, n_max
            do n3 = -n_max, n_max
                
                n_vec = real(n1, 8)*a1 + real(n2, 8)*a2 + real(n3, 8)*a3
                n_norm = norm(n_vec)
                
                ! Second term: sum_{n != 0} erfc(alpha * |n|) / |n|
                !if (n_norm > eps .and. n_norm <= R_cut) then
                if (n_norm > eps) then
                    nu_R = nu_R - erfc(alpha * n_norm) / n_norm
                end if
                
                ! First term: sum_n erfc(alpha * |r + n|) / |r + n|
                r_n = r + n_vec
                r_n_norm = norm(r_n)
                
                !if (r_n_norm > eps .and. r_n_norm <= R_cut) then
                if (r_n_norm > eps) then
                    nu_R = nu_R + erfc(alpha * r_n_norm) / r_n_norm
                else if (r_n_norm <= eps) then
                    ! Note: If r is exactly a lattice vector, this term diverges as 1/r_n.
                    ! The formula provided assumes r is the distance between distinct charges.
                    print *, "Warning: r + n is approximately zero. Term skipped."
                end if
                
            end do
        end do
    end do
    
    ! Add the constant self-term correction from the formula
    nu_R = nu_R + (2.0d0 * alpha) / sqrt(pi)

    !===========================================================================
    ! 4. FOURIER-SPACE SUMMATION (nu_F)
    ! Note: The imaginary sine parts cancel out due to symmetry (k and -k),
    ! so we only compute the real part: cos(k.r) - 1
    !===========================================================================
    nu_F = 0.0d0
    
    do k1 = -k_max, k_max
        do k2 = -k_max, k_max
            do k3 = -k_max, k_max
                
                ! Skip k = 0 term
                if (k1 == 0 .and. k2 == 0 .and. k3 == 0) cycle
                
                k_vec = real(k1, 8)*b1 + real(k2, 8)*b2 + real(k3, 8)*b3
                k_norm = norm(k_vec)
                
                !if (k_norm <= K_cut) then
                k_dot_r = dot_product(k_vec, r)
                nu_F = nu_F + exp(-k_norm**2 / (4.0d0 * alpha**2)) &
                           & / (k_norm**2) * (cos(k_dot_r) - 1.0d0)
                !end if
                
            end do
        end do
    end do
    
    nu_F = (4.0d0 * pi / V) * nu_F

    !===========================================================================
    ! 5. TOTAL INTERACTION AND OUTPUT
    !===========================================================================
    nu_total = nu_R + nu_F

end subroutine tri_e3dtf
