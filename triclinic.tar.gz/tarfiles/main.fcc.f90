program checkphi
  !
  ! compute madelung constant of NaCl, ZnS and CaF2, 
  ! The actu1l primitive vectors for an FCC Bravais lattice 
  !                (with lattice constant of a ) are:
  !
  ! (0,1,1) a/2 ;  (1,0,1) a/2;  (1,1,0) a/2
  !
  ! gfortran -Ofast main.fcc.f90 subroutines.f90 ~/bin/libtools.a
  !
  ! when the subroutine layer_cu2oid_tric() is called,
  ! can not use -Ofast  (do not know why)
  !
  ! instead
  !
  ! gfortran -O2 main.fcc.f90 subroutines.f90 ~/bin/libtools.a
  !
  implicit none
  real(8),parameter:: pi=3.141592653589793d0
  real(8),dimension(1:3):: u1,u2,u3          ! primitive vectors of unit cells
  real(8),dimension(1:3):: va,vb,vc          ! crystal vectors
  integer:: m1, m2, m3, p
  real(8),dimension(1:3):: vr
  !
  !
  real(8):: csum, t1, t2, bd, dv, cf, const, ex_mad
  integer,dimension(1:10):: rep
  real(8):: csum_b, csum_bf, err, errK2, errK4, constfix, scal
  integer:: ip

  !
  ! 
  ! cubic shape (in terms of unit cells)
  m1 = 0; m2 = 0; m3 = 0
  u1=(/0.d0, 1.d0, 1.d0/); u2=(/1.d0, 0.d0, 1.d0/); u3=(/1.d0, 1.d0, 0.d0/)
  p = 1
  va(1:3) = (2*p+1)*(2*m1+1)*u1(1:3)    ! crystal 
  vb(1:3) = (2*p+1)*(2*m2+1)*u2(1:3)
  vc(1:3) = (2*p+1)*(2*m3+1)*u3(1:3)
  rep(1:10) = (/1, 2, 3, 5, 10, 16, 20, 40, 60, 80/)
  open(22,file='fcc.size.dat')

  !
  ! NaCl
  ex_mad = 1.747564594633182d0
  write(22,'(a30,3G24.16)') 'exact Madelung NaCl=', ex_mad
  vr = (/1.0d0, 0.0d0, 0.0d0/)
  call compute_ibterm(va,vb,vc,u1,u2,u3,vr,bd)
  write(22,'(a30,3G24.16)') 'boundary term, bd=', bd

  do ip = 1, 10
    p = rep(ip)
    call layer_diff(u1,u2,u3,m1,m2,m3,p,vr,dv)
    cf = (dble(4*p**2-1))**2/dble(p)/8.0d0
    const = -dv*cf
    
    !
    ! compute direct sum if m1=m2=m3=0 (cubic)
    call layer_dirs_tric(p,vr(1),vr(2),vr(3),u1,u2,u3,csum)

    csum_b = csum-bd; csum_bf = csum-bd-const/(dble(2*p+1))**2
    errK2 = (csum_b - ex_mad)*(dble(2*p+1))**2
    err = csum_bf - ex_mad
    errK4 = err * (dble(2*p+1))**4
    write(22,'(i5,2G15.7,G20.12,2G13.5)')  p, csum_b, errK2, csum_bf, err, errK4
  end do
  write(22,*) 

  !
  ! NaCl irregular shape
  ex_mad = 1.747564594633182d0
  write(22,'(a30,3G24.16)') 'exact Madelung NaCl=', ex_mad
  vr = (/1.0d0, 0.0d0, 0.0d0/)
  call compute_11ir_bterm(u1,u2,u3,vr,bd)
  write(22,'(a30,3G24.16)') 'iregular boundary term', bd

  do ip = 1, 10
    p = rep(ip)
    call layer_11ir_diff(p,u1,u2,u3,vr,dv)
    cf = (dble(4*p**2-1))**2/dble(p)/8.0d0
    const = -dv*cf

    !
    ! compute direct sum iiregular 1x1x1 + (six) 1x1x1 shape
    call layer_11ir(p,vr(1),vr(2),vr(3),u1,u2,u3,csum)

    csum_b = csum-bd; csum_bf = csum-bd-const/(dble(2*p+1))**2
    errK2 = (csum_b - ex_mad)*(dble(2*p+1))**2
    err = csum_bf - ex_mad
    errK4 = err * (dble(2*p+1))**4
    write(22,'(i5,2G15.7,G20.12,2G13.5)')  p, csum_b, errK2, csum_bf, err, errK4
  end do
  write(22,*)


  !
  ! ZnS
  ex_mad = 1.6380550533887894d0; scal = sqrt(3.0d0)*0.5d0
  write(22,'(a30,3G24.16)') 'exact Madelung ZnS=', ex_mad
  vr = (/0.5d0, 0.5d0, 0.5d0/)
  call compute_ibterm(va,vb,vc,u1,u2,u3,vr,bd)
  write(22,'(a30,3G24.16)') 'boundary term*sqrt(3)/2=', bd*scal

  do ip = 1, 10
    p = rep(ip)
    call layer_diff(u1,u2,u3,m1,m2,m3,p,vr,dv)
    cf = (dble(4*p**2-1))**2/dble(p)/8.0d0
    const = -dv*cf

    !
    ! compute direct sum if m1=m2=m3=0 (cubic)
    call layer_dirs_tric(p,vr(1),vr(2),vr(3),u1,u2,u3,csum)

    csum_b = (csum-bd)*scal; csum_bf = (csum-bd-const/(dble(2*p+1))**2)*scal
    errK2 = (csum_b - ex_mad)*(dble(2*p+1))**2
    err = csum_bf - ex_mad
    errK4 = err * (dble(2*p+1))**4
    write(22,'(i5,G15.7,G12.4,G20.12,2G12.4)')  p, csum_b, errK2, csum_bf, err, errK4
  end do
  write(22,*)

  !
  ! ZnS irregular shape
  ex_mad = 1.6380550533887894d0; scal = sqrt(3.0d0)*0.5d0
  write(22,'(a30,3G24.16)') 'exact Madelung ZnS=', ex_mad
  vr = (/0.5d0, 0.5d0, 0.5d0/)
  call compute_11ir_bterm(u1,u2,u3,vr,bd)
  write(22,'(a30,3G24.16)') 'iregular boundary*sqrt(3)/2=', bd*scal

  do ip = 1, 10
    p = rep(ip)
    call layer_11ir_diff(p,u1,u2,u3,vr,dv)
    cf = (dble(4*p**2-1))**2/dble(p)/8.0d0
    const = -dv*cf

    !
    ! compute direct sum iiregular 1x1x1 + (six) 1x1x1 shape
    call layer_11ir(p,vr(1),vr(2),vr(3),u1,u2,u3,csum)

    csum_b = (csum-bd)*scal; csum_bf = (csum-bd-const/(dble(2*p+1))**2)*scal
    errK2 = (csum_b - ex_mad)*(dble(2*p+1))**2
    err = csum_bf - ex_mad
    errK4 = err * (dble(2*p+1))**4
    write(22,'(i5,G15.7,G12.4,G20.12,2G12.4)')  p, csum_b, errK2, csum_bf, err, errK4
  end do
  write(22,*)


  !
  ! CaF_2
  !for Ca^2+, identical to Zn environment
  !for F^-    with Ca^2+  (0.5, 0.5, 0.5)
  !           with F^-    (1, 1, 1) identical to (1, 0, 0)
  close(22)
end program
