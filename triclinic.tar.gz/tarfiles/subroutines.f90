subroutine ffunct(u,t,tau,F_func)
  implicit none
  real(8), parameter :: pi = 3.14159265358979323846d0
  real(8), intent(in) :: u, t, tau

  real(8):: F_func
  !
  !
  real(8) :: term1, term2, term3
  real(8) :: sqrt_ut, sqrt_utau, denom
  
  ! First term: t * asinh(tau/sqrt(u^2 + t^2))
  sqrt_ut = sqrt(u*u + t*t)
  term1 = t * asinh(tau / sqrt_ut)
  
  ! Second term: tau * asinh(t/sqrt(u^2 + tau^2))
  sqrt_utau = sqrt(u*u + tau*tau)
  term2 = tau * asinh(t / sqrt_utau)
  
  ! Third term: u * atan(t*tau/(u*sqrt(u^2 + t^2 + tau^2)))
  denom = sqrt(u*u + t*t + tau*tau)
  if (abs(u) > 1.0d-15) then
    term3 = u * atan((t*tau) / (u*denom))
  else
    ! Handle u = 0 carefully
    if (t*tau >= 0.0d0) then
        term3 = pi/2.0d0 * abs(u)  ! This goes to 0 when u=0
    else
        term3 = -pi/2.0d0 * abs(u) ! This goes to 0 when u=0
    end if
    term3 = 0.0d0  ! Actually when u=0, term3 = 0
  end if
  
  F_func = term1 + term2 - term3
end subroutine ffunct
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine phisquare(Lin,x,y,z,phi0)
  implicit none
  real(8), intent(in) :: x, y, z, Lin

  real(8):: phi0
  !
  ! 
  real(8) :: X_norm, Y_norm, u
  real(8) :: t1, t2, t3, t4
  
  ! Check for l = 0
  if (abs(Lin) < 1.0d-15) then
      phi0 = 0.0d0
      return
  end if
  
  ! Normalized coordinates
  X_norm = x / Lin
  Y_norm = y / Lin
  u = abs(z) / Lin
  
  ! Compute the four F function terms
  call ffunct(u, 1.0d0 - X_norm, 1.0d0 - Y_norm, t1)
  call ffunct(u, 1.0d0 - X_norm, 1.0d0 + Y_norm, t2)
  call ffunct(u, 1.0d0 + X_norm, 1.0d0 - Y_norm, t3)
  call ffunct(u, 1.0d0 + X_norm, 1.0d0 + Y_norm, t4)
  
  ! Sum and multiply by Lin
  phi0 = Lin * (t1 + t2 + t3 + t4)
end subroutine phisquare
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_L(xi, b1, b2, x, y, z, b_val, K_val, &
                     sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                     L1, L2)
  implicit none
  ! Subroutine to compute L1 and L2 for a given xi
  real(8), intent(in) :: xi, b1, b2, x, y, z, b_val, K_val
  real(8), intent(in) :: sqrt_one_minus_b2, sqrtK, sqrt_b_sq
  real(8), intent(out) :: L1, L2
  real(8) :: c_xi, a_xi, s_xi
  real(8) :: u_alpha, st_alpha, T_alpha, d_val
  real(8) :: term1, term2, term3
  real(8) :: denom
  integer :: alpha
  
  denom = b1**2 + b2**2
  
  ! Compute c(xi)
  c_xi = (b2**2 * (x + xi) - b1 * b2 * y) / denom
  
  ! Compute a(xi)
  a_xi = sqrt((b1*y - b2*(x + xi))**2 + denom * z**2) / sqrt_b_sq
  
  ! Compute s(xi)
  s_xi = (b1*(x + xi) + b2*y) / sqrt_b_sq
  
  ! Compute L1 (alpha = 1)
  alpha = 1
  call compute_L_alpha(xi, b1, b2, x, y, z, b_val, K_val, &
                      sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                      c_xi, a_xi, s_xi, alpha, L1)
  
  ! Compute L2 (alpha = 2)
  alpha = 2
  call compute_L_alpha(xi, b1, b2, x, y, z, b_val, K_val, &
                      sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                      c_xi, a_xi, s_xi, alpha, L2)
end subroutine compute_L
subroutine compute_L_alpha(xi, b1, b2, x, y, z, b_val, K_val, &
                           sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                           c_xi, a_xi, s_xi, alpha, L_alpha)
  ! Subroutine to compute L_alpha for specific alpha
  implicit none
  real(8), intent(in) :: xi, b1, b2, x, y, z, b_val, K_val
  real(8), intent(in) :: sqrt_one_minus_b2, sqrtK, sqrt_b_sq
  real(8), intent(in) :: c_xi, a_xi, s_xi
  integer, intent(in) :: alpha
  real(8), intent(out) :: L_alpha
  real(8) :: u_alpha, st_alpha, T_alpha, d_val
  real(8) :: term1, term2, term3
  integer :: tau
  
  ! tau = (-1)^alpha
  tau = (-1)**alpha
  
  ! Compute u_alpha(xi)
  u_alpha = tau * sqrt_b_sq - s_xi
  
  ! Compute d(tau, xi)
  d_val = sqrt((x + xi - tau * b1)**2 + (y - tau * b2)**2 + z**2)
  
  ! Compute st_alpha(xi)
  st_alpha = d_val + u_alpha
  
  ! Compute T_alpha(xi)
  T_alpha = d_val + (x + xi - tau * b1)
  
  ! Check for valid arguments
  if (T_alpha <= 0.0d0 .or. st_alpha <= 0.0d0) then
      print *, "Warning: Non-positive argument for log"
      L_alpha = 0.0d0
      return
  end if
  
  ! Term 1: u_alpha * log(T_alpha)
  term1 = u_alpha * log(T_alpha)
  
  ! Term 2: c(xi) * [log(st_alpha) - b*log(2T_alpha)]/(1-b^2)
  term2 = c_xi * (log(st_alpha) - b_val * log(2.0d0 * T_alpha)) / &
          (1.0d0 - b_val**2)
  
  ! Term 3: atan term
  term3 = (2.0d0 * sqrtK / sqrt_one_minus_b2) * &
          atan(((1.0d0 + b_val) * st_alpha + c_xi) / &
          (sqrt_one_minus_b2 * sqrtK))
  
  L_alpha = term1 + term2 + term3
end subroutine compute_L_alpha
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine phireduced(a1,b1,b2,x,y,z,phi)
  !
  ! formulation of phi using reduced lengths a1, b1, b2
  implicit none
  real(8) :: a1, b1, b2, x, y, z

  real(8) :: phi
  !
  ! Intermediate variables
  real(8) :: b_val, K_val, sqrt_b_sq, denom
  real(8) :: L1_pos, L2_pos, L1_neg, L2_neg
  real(8) :: c_xi, a_xi, s_xi, u_alpha
  real(8) :: d_val, st_alpha, T_alpha
  real(8) :: term1, term2, term3
  real(8) :: sqrtK, sqrt_one_minus_b2
  integer :: alpha, tau
  
    ! Precompute common values
  sqrt_b_sq = sqrt(b1**2 + b2**2)
  denom = b1**2 + b2**2
  
  ! b parameter
  b_val = -b1 / sqrt_b_sq
  
  ! K parameter
  K_val = z**2
  
  ! Square roots for L function
  sqrtK = sqrt(K_val)
  sqrt_one_minus_b2 = sqrt(1.0d0 - b_val**2)
  
  ! Compute L functions at xi = a1 and xi = -a1
  ! First compute L1(a1) and L2(a1)
  call compute_L(a1, b1, b2, x, y, z, b_val, K_val, &
                 sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                 L1_pos, L2_pos)
  
  ! Compute L1(-a1) and L2(-a1)
  call compute_L(-a1, b1, b2, x, y, z, b_val, K_val, &
                 sqrt_one_minus_b2, sqrtK, sqrt_b_sq, &
                 L1_neg, L2_neg)
  
  ! Compute phi
  phi = (abs(b2) * (L2_pos - L1_pos - L2_neg + L1_neg)) / sqrt_b_sq
end subroutine phireduced
subroutine phibasic(a1,a2,a3,b1,b2,b3,x,y,z,phi)
  !
  ! formulation of phi using basic vectors (a1,a2,a3) and (b1,b2,b3)
  implicit none
  real(8):: a1,a2,a3,b1,b2,b3,x,y,z

  real(8):: phi
  !
  !
  real(8), dimension(1:3) :: a_vec, b_vec, r_vec
  real(8), dimension(1:3) :: e_a, e_b

  real(8) :: b, K, prefactor
  real(8) :: sqrtK, sqrt_one_minus_b2


  real(8) :: sum_L
  integer :: xi, tau
  
  ! Vector's norm
  real(8) :: norm_a, norm_b
  
  ! Variables for calculations
  real(8), dimension(1:3) :: R_xi, Q, temp_vec
  real(8) :: c_xi, a_xi, u_val, st_val, T_val
  real(8) :: L_val, term1, term2, term3

  a_vec = (/a1,a2,a3/)
  b_vec = (/b1,b2,b3/)
  r_vec = (/x,y,z/)
  
  !
  ! compute unit vectors
  norm_a = sqrt(dot_product(a_vec, a_vec))
  norm_b = sqrt(dot_product(b_vec, b_vec))
  e_a = a_vec / norm_a
  e_b = b_vec / norm_b

  ! Compute b parameter
  b = -dot_product(e_a, e_b)
  
  ! Compute K and prefactor
  ! First method: using the simpler formula
  !temp_vec = cross_product(e_a, e_b)
  call crs_vdb(e_a,e_b,temp_vec)
  K = (norm_a**2 *dot_product(r_vec,temp_vec)**2)/dot_product(temp_vec,temp_vec)
  prefactor = sqrt(dot_product(temp_vec, temp_vec)) / norm_a

  ! Constants for L function
  sqrtK = sqrt(K)
  sqrt_one_minus_b2 = sqrt(1.0d0 - b**2)

  ! Initialize sum
  sum_L = 0.0d0
  
  ! Loop over xi = ±1, tau = +/- 1
  do xi = -1, 1, 2
    do tau = -1, 1, 2
      
      ! Compute R_xi = r + xi*a
      R_xi = r_vec + xi * a_vec
      
      ! Compute c(xi)
      c_xi = dot_product(a_vec, R_xi - e_b * dot_product(R_xi, e_b))
      
      ! Compute a(xi)
      temp_vec = R_xi - e_b * dot_product(R_xi, e_b)
      a_xi = norm_a * sqrt(dot_product(temp_vec, temp_vec))
      
      ! Compute u(xi,tau)
      u_val = tau * norm_a * norm_b - norm_a * dot_product(R_xi, e_b)
      ! Compute t(xi,tau)
      !st_val = sqrt(u_val**2 + a_xi**2) + u_val          ! <-----
                                                          !      |
      ! Compute T(xi,tau)                                 !      |
      Q = R_xi - tau * b_vec                              !      |
      st_val = sqrt(dot_product(Q, Q)) * norm_a + u_val   ! an aternative
      T_val = sqrt(dot_product(Q, Q)) * norm_a + dot_product(Q, a_vec)

      ! Avoid log(0) or negative arguments
      if (st_val <= 0.0d0 .or. T_val <= 0.0d0) then
        write(*,*) "Warning: non-positive argument for log"
        L_val = 0.0d0
      else
        ! Term 1: u * log(T)
        term1 = u_val * log(T_val)
        
        ! Term 2: c(xi) * [log(t) - b*log(2T)]/(1-b^2)
        term2 = c_xi * (log(st_val) - b*log(2.0d0*T_val)) / &
                (1.0d0 - b**2)
        
        ! Term 3: atan term
        term3 = (2.0d0 * sqrtK / sqrt_one_minus_b2) * &
                atan(((1.0d0 + b) * st_val + c_xi) / &
                (sqrt_one_minus_b2 * sqrtK))
        
        L_val = term1 + term2 + term3
      end if
      
      ! Add to sum with xi*tau factor
      sum_L = sum_L + xi * tau * L_val
      
    end do
  end do
    
    ! Final phi_prime
    phi = prefactor * sum_L 
end subroutine phibasic
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_phi(a_vec, b_vec, r_vec, phi)
  implicit none
  real(8), intent(in)  :: a_vec(3), b_vec(3), r_vec(3)
  real(8), intent(out) :: phi

  ! Local variables
  real(8) :: a, b, dot_ab, c_norm
  real(8) :: e_a(3), e_b(3), c_vec(3)
  real(8) :: c1(3), c2(3)
  real(8) :: p, r1, r2
  real(8) :: phi_g, sum_term
  real(8) :: t, tau
  real(8) :: r_shifted(3), norm_r, dot_with_eb, dot_with_ea
  real(8) :: v_val, w_val, s_val
  real(8) :: log_v, log_w
  integer :: it, itau
  real(8), parameter :: eps = 1.0d-14

  ! Compute magnitudes
  a = sqrt(a_vec(1)**2 + a_vec(2)**2 + a_vec(3)**2)
  b = sqrt(b_vec(1)**2 + b_vec(2)**2 + b_vec(3)**2)

  ! Handle degenerate cases
  if (a < eps .or. b < eps) then
    write(*,*) 'Warning: |a| or |b| too small in compute_phi'
    phi = 0.0d0
    return
  end if

  ! Unit vectors
  e_a(:) = a_vec(:) / a
  e_b(:) = b_vec(:) / b

  ! Dot product e_a · e_b
  dot_ab = e_a(1)*e_b(1) + e_a(2)*e_b(2) + e_a(3)*e_b(3)

  ! Cross product c = e_a × e_b
  c_vec(1) = e_a(2)*e_b(3) - e_a(3)*e_b(2)
  c_vec(2) = e_a(3)*e_b(1) - e_a(1)*e_b(3)
  c_vec(3) = e_a(1)*e_b(2) - e_a(2)*e_b(1)

  c_norm = sqrt(c_vec(1)**2 + c_vec(2)**2 + c_vec(3)**2)

  if (c_norm < eps) then
    write(*,*) 'Warning: e_a and e_b nearly parallel; c \approxi 0'
    phi = 0.0d0
    return
  end if

  ! c1 = e_a - e_b (e_a·e_b)
  c1(:) = e_a(:) - e_b(:) * dot_ab

  ! c2 = e_b - e_a (e_a·e_b)
  c2(:) = e_b(:) - e_a(:) * dot_ab

  ! Projections
  p  = r_vec(1)*c_vec(1) + r_vec(2)*c_vec(2) + r_vec(3)*c_vec(3)
  r1 = r_vec(1)*c1(1)  + r_vec(2)*c1(2)  + r_vec(3)*c1(3)
  r2 = r_vec(1)*c2(1)  + r_vec(2)*c2(2)  + r_vec(3)*c2(3)

  ! Initialize accumulators
  phi_g = 0.0d0
  sum_term = 0.0d0

  ! Loop over t, tau = +/-1
  do it = 1, 2
    t = -1.0d0 + 2.0d0*(it - 1)  ! gives -1, +1
    do itau = 1, 2
      tau = -1.0d0 + 2.0d0*(itau - 1)

      ! Compute shifted vector: r + t*a - tau*b
      r_shifted(:) = r_vec(:) + t*a_vec(:) - tau*b_vec(:)

      ! Norm of shifted vector
      norm_r = sqrt(r_shifted(1)**2 + r_shifted(2)**2 + r_shifted(3)**2)

      ! Avoid log(0) or negative arguments
      if (norm_r < eps) then
          write(*,*) 'Warning: |r + t a - tau b| too small'
          phi = 0.0d0
          return
      end if

      ! Dot products with unit vectors
      dot_with_eb = r_shifted(1)*e_b(1) + r_shifted(2)*e_b(2) &
                  & + r_shifted(3)*e_b(3)
      dot_with_ea = r_shifted(1)*e_a(1) + r_shifted(2)*e_a(2) &
                  & + r_shifted(3)*e_a(3)

      ! v = |R| - R·e_b
      v_val = norm_r - dot_with_eb
      ! w = |R| + R·e_a
      w_val = norm_r + dot_with_ea

      ! Ensure positivity for log
      if (v_val <= 0.0d0 .or. w_val <= 0.0d0) then
          write(*,*) 'Warning: v or w non-positive in compute_phi'
          phi = 0.0d0
          return
      end if

      log_v = log(v_val)
      log_w = log(w_val)

      ! Accumulate phi_g terms
      phi_g = phi_g + c_norm * (a * tau * log_v + b * t * log_w)
      phi_g = phi_g + t * tau * (r1 * log_v - r2 * log_w) / c_norm

      ! Compute s(t,tau)
      s_val = (1.0d0 - dot_ab) * (norm_r + t*a + tau*b) + &
              (r_vec(1)*(e_a(1) - e_b(1)) + &
               r_vec(2)*(e_a(2) - e_b(2)) + &
               r_vec(3)*(e_a(3) - e_b(3)))

      ! Accumulate sum for atan term
      ! Use atan2(s, p) for robustness; if p=0, atan2 handles it
      ! Note: add on Jan 28, 2026
      ! atan2(s,p) returns atan(s/p) in (-pi/2, pi/2) for p > 0
      !                    atan(s,-p)+ pi/2 in (pi/2, pi] for p < 0 and s >= 0
      ! however because t*tau = +/-; the constant of pi/2 might cancel
      sum_term = sum_term + t * tau * atan2(s_val, p)
    end do
  end do

  ! Final phi
  phi = phi_g + (2.0d0 * p / c_norm) * sum_term
  return
end subroutine compute_phi
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine old_compute_grad_phi(a_vec, b_vec, r_vec, grad_phi)
  implicit none
  !
  ! the treatment of arctangent function might have a bug
  ! date: Jun 12, 2026
  real(8), intent(in)  :: a_vec(3), b_vec(3), r_vec(3)
  real(8), intent(out) :: grad_phi(3)

  ! Local variables
  real(8) :: a, b, dot_ab, c_norm
  real(8) :: e_a(3), e_b(3), c_vec(3)
  real(8) :: c1(3), c2(3)
  real(8) :: p, r1, r2
  real(8) :: t, tau
  real(8) :: r_shifted(3), norm_r
  real(8) :: v_val, w_val, s_val
  real(8) :: log_v, log_w
  real(8) :: d_vec(3), d1(3), d2(3), d3(3)
  real(8) :: P1(3), P2(3), P3(3), L_vec(3), Arc_v(3)
  integer :: it, itau, i
  real(8), parameter :: eps = 1.0d-14

  ! Initialize output
  grad_phi(:) = 0.0d0

  ! --- Reuse setup from scalar phi ---
  a = sqrt(dot_product(a_vec, a_vec))
  b = sqrt(dot_product(b_vec, b_vec))

  if (a < eps .or. b < eps) then
    write(*,*) 'Warning: |a| or |b| too small in compute_grad_phi'
    return
  end if

  e_a(:) = a_vec(:) / a
  e_b(:) = b_vec(:) / b

  dot_ab = dot_product(e_a, e_b)

  ! c = e_a × e_b
  c_vec(1) = e_a(2)*e_b(3) - e_a(3)*e_b(2)
  c_vec(2) = e_a(3)*e_b(1) - e_a(1)*e_b(3)
  c_vec(3) = e_a(1)*e_b(2) - e_a(2)*e_b(1)
  c_norm = sqrt(dot_product(c_vec, c_vec))

  if (c_norm < eps) then
    write(*,*) 'Warning: e_a and e_b nearly parallel; c \approxi 0'
    return
  end if

  c1(:) = e_a(:) - dot_ab * e_b(:)
  c2(:) = e_b(:) - dot_ab * e_a(:)

  p  = dot_product(r_vec, c_vec)
  r1 = dot_product(r_vec, c1)
  r2 = dot_product(r_vec, c2)

  ! Initialize accumulators
  P1(:) = 0.0d0
  P2(:) = 0.0d0
  P3(:) = 0.0d0
  L_vec(:) = 0.0d0
  Arc_v(:) = 0.0d0

  ! Loop over t, tau = +/- 1
  do it = 1, 2
    t = -1.0d0 + 2.0d0*(it - 1)
    do itau = 1, 2
      tau = -1.0d0 + 2.0d0*(itau - 1)

      r_shifted(:) = r_vec(:) + t*a_vec(:) - tau*b_vec(:)
      norm_r = sqrt(dot_product(r_shifted, r_shifted))

      if (norm_r < eps) then
        write(*,*) 'Warning: |r + t a - tau b| too small'
        return
      end if

      ! Unit direction vector d(t,tau)
      d_vec(:) = r_shifted(:) / norm_r

      ! v = |R| - R·e_b, w = |R| + R·e_a
      v_val = norm_r - dot_product(r_shifted, e_b)
      w_val = norm_r + dot_product(r_shifted, e_a)

      if (v_val <= 0.0d0 .or. w_val <= 0.0d0) then
        write(*,*) 'Warning: v or w non-positive'
        return
      end if

      log_v = log(v_val)
      log_w = log(w_val)

      ! Compute s(t,tau)
      s_val = (1.0d0-dot_ab)*(norm_r + t*a + tau*b) + dot_product(r_vec, e_a-e_b)

      ! --- Vector fields d1, d2, d3 ---
      d1(:) = d_vec(:) - e_b(:)
      d2(:) = d_vec(:) + e_a(:)
      d3(:) = (1.0d0 - dot_ab) * d_vec(:) + e_a(:) - e_b(:)

      ! --- Accumulate P1 ---
      if (p**2 + s_val**2 > eps) then
        P1(:) = P1(:) + t*tau*(p**2 * d3(:)-p*s_val*c_vec(:)) / (p**2 + s_val**2)
      else
        ! Avoid division by zero; contribution negligible
        write(*,*) 'Warning: p**2 + s_val**2 nearly zero'
        !continue
      end if

      ! --- Accumulate P2 ---
      P2(:) = P2(:) + c_norm * (a * tau * d1(:) / v_val + b * t * d2(:) / w_val)

      ! --- Accumulate P3 ---
      P3(:) = P3(:) + t*tau*(r1*d1(:)/(c_norm*v_val)-r2*d2(:)/(c_norm * w_val))

      ! --- Accumulate L (log term) ---
      L_vec(:) = L_vec(:) + t * tau * (c1(:) * log_v - c2(:) * log_w) / c_norm

      ! --- Accumulate A (arctan term) ---
      ! Note: add on Jan 28, 2026
      ! atan2(s,p) returns atan(s/p) in (-pi/2, pi/2) for p > 0
      !                    atan(s,-p)+ pi/2 in (pi/2, pi] for p < 0 and s >= 0
      ! however because t*tau = +/-; the constant of pi/2 might cancel
      !
      ! here, the treatment of arctangent function still has a bug
      Arc_v(1) = Arc_v(1) + t * tau * atan2(s_val, p)
    end do
  end do

  ! Final assembly
  P1(:) = (2.0d0 / c_norm) * P1(:)
  Arc_v(:) = (2.0d0 / c_norm) * c_vec(:) * Arc_v(1)  !Arc_v(1) holds the scalar sum
  grad_phi(:) = P1(:) + P2(:) + P3(:) + L_vec(:) + Arc_v(:)
  return
end subroutine old_compute_grad_phi
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_gradient_later(a_vec, b_vec, r_vec, g)
  implicit none
  !
  ! Date: jun 12, 2026, written by qiwen
  !
  ! this subroutine is identical to compute_grad_phi()
  ! both should be correct, although notation is different !

  ! 
  real(8), intent(in)  :: a_vec(3), b_vec(3), r_vec(3)
  real(8), intent(out) :: g(3)
  
  ! Scalar variables
  real(8) :: a, b, v, r0, r1, r2, ea_dot_eb
  real(8) :: s1, s2, s3, rs_mag
  real(8) :: term_A, A_sum, denom, denom_G3
  
  ! Vector variables
  real(8) :: ea(3), eb(3), v0(3), v1(3), v2(3)
  real(8) :: rs(3), d(3), d1(3), d2(3), d3(3)
  real(8) :: G1(3), G2(3), G3(3), L_vec(3), Ar_vec(3)
  real(8) :: term_G1(3), term_G2(3), term_G3(3), term_L(3)
  
  integer :: t, tau
  
  ! 1. Compute magnitudes and unit vectors
  a = sqrt(dot_product(a_vec, a_vec))
  b = sqrt(dot_product(b_vec, b_vec))
  
  ! Handle degenerate case where a or b is a zero vector
  if (a < 1.0d-12 .or. b < 1.0d-12) then
      g = 0.0d0
      return
  end if
  
  ea = a_vec / a
  eb = b_vec / b
  ea_dot_eb = dot_product(ea, eb)
  
  ! 2. Compute orthogonal components and cross product
  ! v0 = ea x eb
  v0(1) = ea(2)*eb(3) - ea(3)*eb(2)
  v0(2) = ea(3)*eb(1) - ea(1)*eb(3)
  v0(3) = ea(1)*eb(2) - ea(2)*eb(1)
  
  v = sqrt(dot_product(v0, v0))
  
  ! Handle degenerate case where a and b are parallel
  if (v < 1.0d-12) then
      g = 0.0d0
      return
  end if
  
  v1 = ea - eb * ea_dot_eb
  v2 = eb - ea * ea_dot_eb
  
  ! 3. Compute projections of r
  r0 = dot_product(r_vec, v0) / v
  r1 = dot_product(r_vec, v1) / v
  r2 = dot_product(r_vec, v2) / v
  
  ! 4. Initialize accumulation variables
  G1    = 0.0d0
  G2    = 0.0d0
  G3    = 0.0d0
  L_vec = 0.0d0
  A_sum = 0.0d0
  
  ! 5. Loop over t, tau in {-1, +1}
  do t = -1, 1, 2
      do tau = -1, 1, 2
          
          rs = r_vec + real(t, 8)*a_vec - real(tau, 8)*b_vec
          rs_mag = sqrt(dot_product(rs, rs))
          
          ! Skip if exactly at a vertex (singularity)
          if (rs_mag < 1.0d-12) cycle
          
          d  = rs / rs_mag
          d1 = d + ea
          d2 = d - eb
          d3 = (1.0d0 - ea_dot_eb) * d + ea - eb
          
          s1 = rs_mag + dot_product(ea, rs)
          s2 = rs_mag - dot_product(eb, rs)
          s3 = rs_mag * (1.0d0 - ea_dot_eb) + dot_product(rs, ea - eb)
          
          ! Numerical safeguards against log(0) or division by zero
          s1 = max(s1, 1.0d-15)
          s2 = max(s2, 1.0d-15)
          
          ! --- G1 term ---
          term_G1 = real(t, 8) * (b * v - real(tau, 8) * r2) * (d1 / s1)
          G1 = G1 + term_G1
          
          ! --- G2 term ---
          term_G2 = real(tau, 8) * (a * v + real(t, 8) * r1) * (d2 / s2)
          G2 = G2 + term_G2
          
          ! --- G3 term ---
          denom_G3 = v**2 * r0**2 + s3**2
          if (denom_G3 < 1.0d-15) denom_G3 = 1.0d-15
          term_G3 = 2.0d0 * r0 * real(t, 8) * real(tau, 8) * &
                    (v * r0 * d3 - s3 * v0) / denom_G3
          G3 = G3 + term_G3
          
          ! --- L term ---
          term_L = real(t, 8) * real(tau, 8) * (v1 * log(s2) - v2 * log(s1)) / v
          L_vec = L_vec + term_L
          
          ! --- A term (scalar accumulation) ---
          denom = v * r0
          ! Safeguard for atan denominator to preserve correct sign limit
          if (abs(denom) < 1.0d-12) then
              if (r0 >= 0.0d0) then
                  denom = 1.0d-12
              else
                  denom = -1.0d-12
              end if
          end if
          term_A = real(t, 8) * real(tau, 8) * atan(s3 / denom)
          A_sum = A_sum + term_A
          
      end do
  end do
  
  ! 6. Finalize vector A
  Ar_vec = (2.0d0 / v) * v0 * A_sum
  
  ! 7. Total gradient
  g = G1 + G2 + G3 + L_vec + Ar_vec
  
end subroutine compute_gradient_later
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_grad_phi(a_vec, b_vec, r_vec, grad_phi)
  implicit none
  !
  !  compute_grad_phi():  notation are the same as in the paper
  !  Date: Jun 12, 2026
  !
  ! this subroutine is identical to old_compute_grad_phi()
  !      which was written earlier and have a bug for arctangent function.
  !
  ! later on, qiwen gives a better subroutine to handle r0 * arctan( something/ r0 ) 
  ! see subroutine compute_gradient_later()
  !
  real(8), intent(in)  :: a_vec(3), b_vec(3), r_vec(3)
  real(8), intent(out) :: grad_phi(3)

  ! Local variables
  real(8) :: a, b, dot_ab, v_norm
  real(8) :: e_a(3), e_b(3), v0(3)
  real(8) :: v1(3), v2(3)
  real(8) :: r0, r1, r2
  real(8) :: t, tau, demon
  real(8) :: r_shifted(3), norm_r
  real(8) :: s2_val, s1_val, s3_val
  real(8) :: log_s2, log_s1
  real(8) :: d_vec(3), d1(3), d2(3), d3(3)
  real(8) :: G3(3), G1(3), G2(3), L_vec(3), Arc_v(3)
  integer :: it, itau, i
  real(8), parameter :: eps = 1.0d-14

  ! Initialize output
  grad_phi(:) = 0.0d0

  ! --- Reuse setup from scalar phi ---
  a = sqrt(dot_product(a_vec, a_vec))
  b = sqrt(dot_product(b_vec, b_vec))

  if (a < eps .or. b < eps) then
    write(*,*) 'Warning: |a| or |b| too small in compute_grad_phi'
    return
  end if

  e_a(:) = a_vec(:) / a
  e_b(:) = b_vec(:) / b

  dot_ab = dot_product(e_a, e_b)

  ! c = e_a × e_b
  v0(1) = e_a(2)*e_b(3) - e_a(3)*e_b(2)
  v0(2) = e_a(3)*e_b(1) - e_a(1)*e_b(3)
  v0(3) = e_a(1)*e_b(2) - e_a(2)*e_b(1)
  v_norm = sqrt(dot_product(v0, v0))

  if (v_norm < eps) then
    write(*,*) 'Warning: e_a and e_b nearly parallel; c \approxi 0'
    return
  end if

  v1(:) = e_a(:) - dot_ab * e_b(:)
  v2(:) = e_b(:) - dot_ab * e_a(:)

  r0 = dot_product(r_vec, v0); r0 = r0/v_norm
  r1 = dot_product(r_vec, v1); r1 = r1/v_norm
  r2 = dot_product(r_vec, v2); r2 = r2/v_norm

  ! Initialize accumulators
  G3(:) = 0.0d0
  G1(:) = 0.0d0
  G2(:) = 0.0d0
  L_vec(:) = 0.0d0
  Arc_v(:) = 0.0d0

  ! Loop over t, tau = +/- 1
  do it = 1, 2
    t = -1.0d0 + 2.0d0*(it - 1)
    do itau = 1, 2
      tau = -1.0d0 + 2.0d0*(itau - 1)

      r_shifted(:) = r_vec(:) + t*a_vec(:) - tau*b_vec(:)
      norm_r = sqrt(dot_product(r_shifted, r_shifted))

      if (norm_r < eps) then
        write(*,*) 'Warning: |r + t a - tau b| too small'
        return
      end if

      !
      ! Compute s(t,tau)
      ! v = |R| - R·e_b, w = |R| + R·e_a
      s2_val = norm_r - dot_product(r_shifted, e_b)
      s1_val = norm_r + dot_product(r_shifted, e_a)
      s3_val = (1.0d0-dot_ab)*norm_r + dot_product(r_shifted, e_a-e_b)


      if (s2_val <= 0.0d0 .or. s1_val <= 0.0d0) then
        write(*,*) 'Warning: v or w non-positive'
        return
      end if

      log_s1 = log(s1_val)
      log_s2 = log(s2_val)


      ! --- Vector fields d1, d2, d3 ---
      d_vec(:) = r_shifted(:) / norm_r
      d1(:) = d_vec(:) + e_a(:)
      d2(:) = d_vec(:) - e_b(:)
      d3(:) = (1.0d0 - dot_ab) * d_vec(:) + e_a(:) - e_b(:)

      ! --- Accumulate G3 ---
      if (r0**2 + s3_val**2 > eps) then
        G3(:) = G3(:) + t*tau*(v_norm*r0*d3(:) - s3_val*v0(:)) &
                          & / (v_norm**2*r0**2 + s3_val**2)
      else
        ! Avoid division by zero; contribution negligible
        write(*,*) 'Warning: v_norm**2*r0**2 + s3_val**2 nearly zero'
        !continue
      end if

      ! --- Accumulate G1 and G2
      G1(:) = G1(:) +  t *(b * v_norm - tau * r2) * d1(:)/s1_val
      G2(:) = G2(:) + tau*(a * v_norm + t * r1  ) * d2(:)/s2_val

      ! --- Accumulate L (log term) ---
      L_vec(:) = L_vec(:) + t * tau * (v1(:) * log_s2 - v2(:) * log_s1) / v_norm

      ! --- Accumulate A (arctan term) --- one must be careful for small r0
      ! there was a bug to treat arctangent function here,
      !          because r0 could be negative    !!!!!!!!!!!!!!
      !if ( r0 .gt. eps ) then
      !  Arc_v(1) = Arc_v(1) + t * tau * atan(s3_val/(r0*v_norm))
      !else
      !  write(*,*) "warning: r0 too small"
      !end if

      demon = r0*v_norm
      ! Safeguard for atan denominator to preserve correct sign limit
      if (abs(demon) < 1.0d-12) then
          if (r0 >= 0.0d0) then
              demon = 1.0d-12
          else
              demon = -1.0d-12
          end if
      end if
      Arc_v(1) = Arc_v(1) + t * tau * atan(s3_val/demon)
    end do
  end do

  ! Final assembly
  G3(:) = (2.0d0 * r0) * G3(:)
  Arc_v(:) = (2.0d0 / v_norm) * v0(:) * Arc_v(1)  !Arc_v(1) holds the scalar sum
  grad_phi(:) = G3(:) + G1(:) + G2(:) + L_vec(:) + Arc_v(:)
  return
end subroutine compute_grad_phi
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_ibterm(a_vec, b_vec, c_vec, ua,ub,uc,r_vec, ibt)
  implicit none
  !
  ! compute infinite bouddary term ibt
  real(8), intent(in)  :: a_vec(3), b_vec(3), c_vec(3) !crystal vectors
  real(8), intent(in)  :: r_vec(3)  ! relative displacement
  real(8), intent(in)  :: ua(3), ub(3), uc(3)     !unit cell vectors

  real(8), intent(out) :: ibt
  !
  ! Local variables
  real(8) :: a, b, c, vol
  real(8) :: e_a(3), e_b(3), e_c(3), crs_v(3)
  real(8) :: grad(3)

  ibt = 0.0d0

  !
  ! a b plane
  a = sqrt(dot_product(a_vec, a_vec))
  b = sqrt(dot_product(b_vec, b_vec))
  e_a(:) = a_vec(:) / a; e_b(:) = b_vec(:) / b
  ! crs_v = e_a × e_b
  crs_v(1) = e_a(2)*e_b(3) - e_a(3)*e_b(2)
  crs_v(2) = e_a(3)*e_b(1) - e_a(1)*e_b(3)
  crs_v(3) = e_a(1)*e_b(2) - e_a(2)*e_b(1)
  call compute_grad_phi(a_vec,b_vec,c_vec,grad)
  grad(:) = grad(:)/sqrt( dot_product(crs_v, crs_v))
  ibt = ibt + dot_product(r_vec,crs_v) * dot_product(r_vec, grad)

  !
  ! c a plane
  c = sqrt(dot_product(c_vec, c_vec))
  e_c(:) = c_vec(:)/c
  ! crs_v = e_c × e_a
  crs_v(1) = e_c(2)*e_a(3) - e_c(3)*e_a(2)
  crs_v(2) = e_c(3)*e_a(1) - e_c(1)*e_a(3)
  crs_v(3) = e_c(1)*e_a(2) - e_c(2)*e_a(1)
  call compute_grad_phi(c_vec,a_vec,b_vec,grad)
  grad(:) = grad(:)/sqrt( dot_product(crs_v, crs_v))
  ibt = ibt + dot_product(r_vec,crs_v) * dot_product(r_vec, grad)

  !
  ! b c plane
  ! crs_v = e_b × e_c
  crs_v(1) = e_b(2)*e_c(3) - e_b(3)*e_c(2)
  crs_v(2) = e_b(3)*e_c(1) - e_b(1)*e_c(3)
  crs_v(3) = e_b(1)*e_c(2) - e_b(2)*e_c(1)
  call compute_grad_phi(b_vec,c_vec,a_vec,grad)
  grad(:) = grad(:)/sqrt( dot_product(crs_v, crs_v))
  ibt = ibt + dot_product(r_vec,crs_v) * dot_product(r_vec, grad)

  ! volume of unit cell
  ! Noting that the side vectors of the crystal does not necessarily coincide
  !             with the side vectors of the unit cell.
  crs_v(1) = ub(2)*uc(3) - ub(3)*uc(2)
  crs_v(2) = ub(3)*uc(1) - ub(1)*uc(3)
  crs_v(3) = ub(1)*uc(2) - ub(2)*uc(1)
  vol = abs(dot_product(crs_v(:), ua(:)))
  ibt = ibt/vol
  return
end subroutine compute_ibterm
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_11ir_b5(ua,ub,uc,r_vec, ibt)
  implicit none
  !
  ! compute infinite bouddary term of an irregular crystal
  ! six blocks attached to a cubic (in terms of unit cells)
  !
  ! 1 X 1 X 1 + (six) 1 X 1 X 1          11ir  shape
  !
  ! in total 30 parallelogram facets
  ! this one computes 10 of them, degeneracy of 2, actually, 5 of them
  !
  ! 5 facets of a block
  !
  real(8), intent(in)  :: r_vec(3)  ! relative displacement
  real(8), intent(in)  :: ua(3), ub(3), uc(3)     !unit cell vectors

  real(8), intent(out) :: ibt
  !
  ! Local variables
  real(8):: a_vec(3), b_vec(3), c_vec(3) !crystal vectors
  real(8) :: a, b, c, vol
  real(8) :: e_a(3), e_b(3), e_c(3), crs_v(3)
  real(8) :: grad(3)
  integer:: i

  ibt = 0.0d0

  do i = 1,  5
    if ( i.eq.1 ) then
      a_vec(:) = ua(:); b_vec(:) = ub(:); c_vec(:) = uc(:)*3.0d0
    else if ( i.eq.2 ) then
      a_vec(:) = ub(:); b_vec(:) = uc(:); c_vec(:) = 2.0d0*uc(:) + ua(:)
    else if ( i.eq. 3) then
      a_vec(:) = uc(:); b_vec(:) = ub(:); c_vec(:) = 2.0d0*uc(:) - ua(:)
    else if ( i.eq. 4) then
      a_vec(:) = uc(:); b_vec(:) = ua(:); c_vec(:) = 2.0d0*uc(:) + ub(:)
    else if ( i.eq. 5) then
      a_vec(:) = ua(:); b_vec(:) = uc(:); c_vec(:) = 2.0d0*uc(:) - ub(:)
    end if
    !
    !
    a = sqrt(dot_product(a_vec, a_vec))
    b = sqrt(dot_product(b_vec, b_vec))
    e_a(:) = a_vec(:) / a; e_b(:) = b_vec(:) / b
    ! crs_v = e_a × e_b
    crs_v(1) = e_a(2)*e_b(3) - e_a(3)*e_b(2)
    crs_v(2) = e_a(3)*e_b(1) - e_a(1)*e_b(3)
    crs_v(3) = e_a(1)*e_b(2) - e_a(2)*e_b(1)
    crs_v(:) = crs_v(:)/sqrt( dot_product(crs_v, crs_v))
    call compute_grad_phi(a_vec,b_vec,c_vec,grad)
    ibt = ibt + dot_product(r_vec,crs_v) * dot_product(r_vec, grad)
  end do
end subroutine compute_11ir_b5
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine compute_11ir_bterm(ua,ub,uc,r_vec, ibt)
  implicit none
  !
  ! compute infinite bouddary term of an irregular crystal
  ! six blocks attached to a cubic (in terms of unit cells)
  !
  ! 1 X 1 X 1 + (six) 1 X 1 X 1
  !
  ! in total 30 parallelogram facets
  !
  !
  real(8), intent(in)  :: r_vec(3)  ! relative displacement
  real(8), intent(in)  :: ua(3), ub(3), uc(3)     !unit cell vectors

  real(8), intent(out) :: ibt
  !
  ! Local variables
  real(8) :: vol, ibt5
  real(8) :: crs_v(3)
  !
  !
  call compute_11ir_b5(ua,ub,uc,r_vec, ibt)
  call compute_11ir_b5(ub,uc,ua,r_vec, ibt5)
  ibt = ibt + ibt5
  call compute_11ir_b5(uc,ua,ub,r_vec, ibt5)
  ibt = ibt + ibt5
  !
  ! volume of unit cell
  ! Noting that the side vectors of the crystal does not necessarily coincide
  !             with the side vectors of the unit cell.
  crs_v(1) = ub(2)*uc(3) - ub(3)*uc(2)
  crs_v(2) = ub(3)*uc(1) - ub(1)*uc(3)
  crs_v(3) = ub(1)*uc(2) - ub(2)*uc(1)
  vol = abs(dot_product(crs_v(:), ua(:)))
  ibt = ibt/vol
  return
end subroutine compute_11ir_bterm
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_diff(ua,ub,uc,n1,n2,n3,p,vr,dv)
  !
  ! for a triclinic lattice
  !
  ! compute the difference between a crystal with # of unit cells:
  !                  (2p+1)^3 * (2 n_1 + 1)*(2 n_2 + 1)*(2 n_3 + 1)
  !          and a crystal with # of unit cells:
  !                  (2p-1)^3 * (2 n_1 + 1)*(2 n_2 + 1)*(2 n_3 + 1)
  !
  !  n_1, n_2, n_3 >= 0    all integers
  !  size p >= 1
  !
  ! two particle crystal relative displacement: vr
  !
  ! basic vectors of the unit cell:  ua, ub, uc
  !
  ! ----- ----- ----- ----- ----- ----- ----- ----- ----- 
  !
  ! inner crystal [-i1,i1] X [-i2,i2] X [-i3,i3]
  ! outer crystal [-p1,p1] X [-p2,p2] X [-p3,p3]
  !
  implicit none
  real(8),dimension(1:3):: ua,ub,uc, vr
  integer:: n1, n2, n3, p

  real(8):: dv       ! output potential
  !
  !
  integer:: p1, p2, p3, i1,i2,i3
  real(8),dimension(1:3):: vn, vrn
  real(8):: csum, t1, t2, bd
  integer:: ia,ib,ic
  logical:: inside

  if (p.le.0) then
    write(*,*) "p should be .ge. 1", p
    stop 'subroutine layer_diff()'
  end if

  if (n1.lt.0 .or. n2.lt.0 .or. n3.lt.0 ) then
    write(*,*) "n1, n2, n3 should be greater than 0", n1,n2,n3
    stop 'subroutine layer_diff()'
  end if
  

  p1 = p*2*n1+p+n1; p2 = p*2*n2+p+n2; p3 = p*2*n3+p+n3
  i1 = p1-(2*n1+1); i2 = p2-(2*n2+1); i3 = p3-(2*n3+1)
 
  csum = 0.0d0
  do ia = -p1, p1
    do ib = -p2, p2
      do ic = -p3, p3
        inside = ia.ge.-i1 .and. ia.le.i1 .and. ib.ge.-i2 .and. ib.le.i2 &
               & .and. ic.ge.-i3 .and. ic.le.i3
        if ( .not. inside ) then   ! sandiwiched region
          vn(1:3) = dble(ia)*ua(:) + dble(ib)*ub(:) + dble(ic)*uc(:)
          t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
          vrn(1:3) = vr(1:3) + vn(1:3)
          t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
          csum = csum + 1.d0/t2 - 1.d0/t1
        end if
      end do
    end do
  end do
  dv = csum
  return
end subroutine layer_diff
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine chk_11ir(p,ia,ib,ic,is)
  implicit none
  !
  ! check whether an index (ia,ib,ic) is inside the iregular crystal of size p
  !
  ! is = 1  yes
  ! is = 0  no
  integer:: p, ia, ib, ic
  
  integer:: is
  !
  !
  if ( ia.ge.-p .and. ia.le.p .and. ib.ge.-p .and. ib.le.p .and. &
     & ic.ge.-p .and. ic.le.p ) then
    is = 1; return
  else if (ia.ge.p+1 .and. ia.le.3*p+1 .and. ib.ge.-p .and. ib.le.p .and. &
     & ic.ge.-p .and. ic.le.p ) then
    is = 1; return
  else if (ia.ge.-(3*p+1) .and. ia.le.-(p+1) .and. ib.ge.-p .and. ib.le.p .and. &
     & ic.ge.-p .and. ic.le.p ) then
    is = 1; return
  else if (ib.ge.p+1 .and. ib.le.3*p+1 .and. ia.ge.-p .and. ia.le.p .and. &
     & ic.ge.-p .and. ic.le.p ) then
    is = 1; return
  else if (ib.ge.-(3*p+1) .and. ib.le.-(p+1) .and. ia.ge.-p .and. ia.le.p .and. &
     & ic.ge.-p .and. ic.le.p ) then
    is = 1; return
  else if (ic.ge.p+1 .and. ic.le.3*p+1 .and. ib.ge.-p .and. ib.le.p .and. &
     & ia.ge.-p .and. ia.le.p ) then
    is = 1; return
  else if (ic.ge.-(3*p+1) .and. ic.le.-(p+1) .and. ib.ge.-p .and. ib.le.p .and. &
     & ia.ge.-p .and. ia.le.p ) then
    is = 1; return
  end if
  is = 0
  return
end subroutine chk_11ir
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_11ir_diff(p,ua,ub,uc,vr,csum)
  !
  ! for irregular crystals in a triclinic lattice
  !
  ! shape   1x1x1 + (six) 1x1x1
  !
  ! compute the difference between this crystal of size p
  !          and a crystal of size p-1
  !
  !  size p >= 1
  !
  ! two particle crystal relative displacement: vr
  !
  ! basic vectors of the unit cell:  ua, ub, uc
  !
  implicit none
  real(8),dimension(1:3):: ua,ub,uc, vr
  integer:: p

  real(8):: csum       ! output potential
  !
  !
  real(8),dimension(1:3):: vn, vrn
  real(8):: t1, t2
  integer:: i,j,k, ib, init, endd
  integer:: p1, is

  if (p.le.0) then
    write(*,*) "p should be .ge. 1", p
    stop 'subroutine layer_11ir_diff()'
  end if

  p1 = p-1
  csum = 0.0d0
  do ib = 1, 2
    if (ib.eq.1) then
      init = p+1; endd = 3*p + 1
    else if ( ib.eq.2) then
      init = -(3*p+1); endd = -(p+1)
    end if
    !
    ! z direction block
    do k = init, endd
      do i = -p, p
        do j = -p, p
          call chk_11ir(p1,i,j,k,is)
          if (is .eq. 0) then
            vn(1:3) = dble(i)*ua(:) + dble(j)*ub(:) + dble(k)*uc(:)
            t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
            vrn(1:3) = vr(1:3) + vn(1:3)
            t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
            csum = csum + 1.d0/t2 - 1.d0/t1
          end if
        end do
      end do
    end do
    !
    ! x direction block
    do k = -p, p
      do i = init, endd
        do j = -p, p
          call chk_11ir(p1,i,j,k,is)
          if (is .eq. 0) then
            vn(1:3) = dble(i)*ua(:) + dble(j)*ub(:) + dble(k)*uc(:)
            t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
            vrn(1:3) = vr(1:3) + vn(1:3)
            t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
            csum = csum + 1.d0/t2 - 1.d0/t1
          end if
        end do
      end do
    end do
    !
    ! y direction block
    do k = -p, p
      do i = -p, p
        do j = init, endd
          call chk_11ir(p1,i,j,k,is)
          if (is .eq. 0) then
            vn(1:3) = dble(i)*ua(:) + dble(j)*ub(:) + dble(k)*uc(:)
            t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
            vrn(1:3) = vr(1:3) + vn(1:3)
            t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
            csum = csum + 1.d0/t2 - 1.d0/t1
          end if
        end do
      end do
    end do
  end do
  !
  ! cubk (in terms of unit cells)
  do i = -p, p
    do j = -p, p
      do k = -p, p
        call chk_11ir(p1,i,j,k,is)
        if (is.eq.0) then
          vn(1:3) = dble(i)*ua(:) + dble(j)*ub(:) + dble(k)*uc(:)
          t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
          vrn(1:3) = vr(1:3) + vn(1:3)
          t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
          csum = csum + 1.d0/t2 - 1.d0/t1
        end if
      end do
    end do
  end do
  return
end subroutine layer_11ir_diff
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine inaccurate_tric_direct_reg(n1,n2,n3,p,ua,ub,uc,vr,csum)
  implicit none

  ! compute direct summation for a regular crystal in a triclinic lattice 
  !
  ! unit cell vectors:     ua(1:3), ub(1:3), uc(1:3)
  ! input displacement:    vr(1:3)
  !
  ! size index:     p
  ! regular shape:  (2*n1+1),   (2*n2+1),    (2*n3+1) in terms of unit cells
  !
  ! total dimensions of crystal: (2*p1+1) by (2*p2+1) by (2*p3+1)  unit cells
  ! 
  ! this subroutine is not accurate for large p
  ! e.g. p = 160,  n1=n2=n3 =0
  integer:: n1, n2, n3, p
  real(8),dimension(1:3):: ua, ub, uc, vr
  
  real(8):: csum
  !
  !
  integer:: p1, p2, p3
  integer:: ia, ib, ic, is
  real(8),dimension(1:3):: vn, vrn
  real(8):: t1, t2
  
  p1 = p*2*n1+p+n1; p2 = p*2*n2+p+n2; p3 = p*2*n3+p+n3


  !
  ! direct sum
  csum = 1.0d0/sqrt( vr(1)*vr(1) + vr(2)*vr(2) + vr(3)*vr(3) )
  do ia = -p1, p1
    do ib = -p2, p2
      do ic = -p3, p3
        is = ia**2 + ib**2 + ic**2
        if ( is .ne. 0 ) then
          vn(1:3) = dble(ia)*ua(:) + dble(ib)*ub(:) + dble(ic)*uc(:)
          t1 = sqrt( vn(1)* vn(1)+ vn(2)* vn(2)+ vn(3)* vn(3))
          vrn(1:3) = vr(1:3) + vn(1:3)
          t2 = sqrt(vrn(1)*vrn(1)+vrn(2)*vrn(2)+vrn(3)*vrn(3))
          csum = csum + 1.d0/t2 - 1.d0/t1
        end if
      end do
    end do
  end do
  return
end subroutine inaccurate_tric_direct_reg
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_dirs_tric(nlayer,x,y,z,ua,ub,uc,dirs)
  !
  ! see an inaccurate subroutine inaccurate_tric_direct_reg()
  !
  ! compute the direct sum layer by layer from outside to inside
  ! nlayer = n 
  ! split every (2n+1)^3 - (2n-1)^3 boxes outside into
  !   z:    2 X (2n+1)^2
  !   x:    2 X (2n+1) X (2n-1)
  !   y:    2 X (2n-1) X (2n-1) 
  !
  ! see layer_dirs() in papers26/fcrystal/data/evencub/sub_layer.f90
  !                     papers26/latticeJPCL/data/sub_layer.f90
  ! 
  ! Date: Jun 13, 2026
  !
  !
  implicit none
  integer:: nlayer      ! size p
  real(8):: x,y,z
  real(8),dimension(1:3):: ua,ub,uc
 
  real(8):: dirs
  !
  ! intermediate
  real(8):: rx0, ry0, rz0
  real(8):: rx,ry,rz, rsq,sqn
  integer:: i,j,k, is, nout

  dirs = 0.0d0
  do nout = nlayer, 1, -1

    do k = -nout, nout, 2*nout      ! z
      do i = -nout, nout
        do j = -nout, nout
          rx = x + dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry = y + dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz = z + dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          rsq = sqrt(rx**2 + ry**2 + rz**2)
          rx0 = dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry0 = dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz0 = dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          sqn = sqrt(rx0**2 + ry0**2 + rz0**2)
          dirs = dirs + 1.0d0/rsq - 1.0d0/sqn
        end do
      end do
    end do

    do i = -nout, nout, 2*nout      ! x
      do j = -nout, nout
        do  k = -nout+1, nout - 1   ! z
          rx = x + dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry = y + dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz = z + dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          rsq = sqrt(rx**2 + ry**2 + rz**2)
          rx0 = dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry0 = dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz0 = dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          sqn = sqrt(rx0**2 + ry0**2 + rz0**2)
          dirs = dirs + 1.0d0/rsq - 1.0d0/sqn
        end do
      end do
    end do

    do j = -nout, nout, 2*nout      ! y
      do i = -nout+1, nout - 1      ! x
        do k = -nout+1, nout - 1   ! z
          rx = x + dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry = y + dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz = z + dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          rsq = sqrt(rx**2 + ry**2 + rz**2)
          rx0 = dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry0 = dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz0 = dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          sqn = sqrt(rx0**2 + ry0**2 + rz0**2)
          dirs = dirs + 1.0d0/rsq - 1.0d0/sqn
        end do
      end do
    end do

  end do
  nout = 0  ! the center term
  dirs = dirs + 1.0d0/sqrt(x**2+y**2+z**2)
  return

end subroutine layer_dirs_tric
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_11ir_2block(nlayer,x,y,z,ua,ub,uc,dirs_io)
  !
  ! compute the direct sum layer by layer from outside to inside
  ! nlayer = p 
  !
  ! (2p+1)**3  + (six) (2p+1)**3          11ir shape crystal
  !
  ! Date: Jun 14, 2026
  !
  implicit none
  integer:: nlayer      ! size p
  real(8):: x,y,z
  real(8),dimension(1:3):: ua,ub,uc
 
  real(8):: dirs_io

  !
  ! intermediate
  integer:: p
  real(8):: rx0, ry0, rz0
  real(8):: rx,ry,rz, rsq,sqn
  integer:: i,j,k, ib, inik, endk

  !
  !noting that there is no initial of dirs_io = 0.0d0
  p = nlayer
  do ib = 1, 2
    if (ib.eq.1) then
      inik = p+1; endk = 3*p + 1
    else if ( ib.eq.2) then
      inik = -(3*p+1); endk = -(p+1)
    end if
    do k = inik, endk
      do i = -p, p 
        do j = -p, p
          rx = x + dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry = y + dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz = z + dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          rsq = sqrt(rx**2 + ry**2 + rz**2)
          rx0 = dble(i)*ua(1) + dble(j)*ub(1) + dble(k)*uc(1)
          ry0 = dble(i)*ua(2) + dble(j)*ub(2) + dble(k)*uc(2)
          rz0 = dble(i)*ua(3) + dble(j)*ub(3) + dble(k)*uc(3)
          sqn = sqrt(rx0**2 + ry0**2 + rz0**2)
          dirs_io = dirs_io + 1.0d0/rsq - 1.0d0/sqn
        end do
      end do
    end do
  end do
  return
end subroutine layer_11ir_2block
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_11ir(p, x,y,z,ua,ub,uc,dirs)
  !
  ! Date: Jun 14, 2026
  !
  implicit none
  integer:: p
  real(8):: x,y,z
  real(8),dimension(1:3):: ua,ub,uc

  real(8):: dirs
  !
  real(8):: dirsc
  !
  ! compute blocks first
  dirs = 0.0d0
  call layer_11ir_2block(p,x,y,z,ua,ub,uc,dirs)
  call layer_11ir_2block(p,x,y,z,ub,uc,ua,dirs)
  call layer_11ir_2block(p,x,y,z,uc,ua,ub,dirs)
  !
  ! compute layer by layer
  call layer_dirs_tric(p, x,y,z,ua,ub,uc,dirsc)
  dirs = dirs + dirsc
  return
end subroutine layer_11ir
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
subroutine layer_cuboid_tric(ntotal,ps,m1,m2,m3,x,y,z,ua,ub,uc,dirs)
  !
  ! compute the direct sum layer by layer from outside to inside
  !
  ! ps = p      size of the cuboid crystal
  !
  ! the layer is cuboid shape, (2m_1 + 1)*(2p + 1) = 2n_1 + 1   x direction
  !                            (2m_2 + 1)*(2p + 1) = 2n_2 + 1   y direction
  !                            (2m_3 + 1)*(2p + 1) = 2n_3 + 2   z direction
  !
  ! in terms of unit cells
  !
  ! date: Jun. 13, 2026
  !
  ! see also layer_cuboid() in  papers26/fcrystal/data/evencub/sub_layer.f90
  !                             papers26/latticeJPCL/data/sub_layer.f90
  !
  implicit none
  integer:: m1,m2,m3, ps
  real(8):: x,y,z
  real(8),dimension(1:3):: ua,ub,uc
 
  real(8):: dirs
  !
  ! intermediate
  integer:: nn1, nn2, nn3
  integer(8):: ntotal
  integer(8),parameter:: o=1
  integer(8):: io
  integer,dimension(o:ntotal):: indx,indy,indz
  integer(8),dimension(1:ps+1):: nt, nc
  real(8):: rx,ry,rz, rsq, sqn, rx0,ry0,rz0
  integer:: ix,iy,iz
  integer:: i,j,k, is

  !
  ! redefine
  nn1 = ((2*ps + 1) * (2*m1+1) - 1)/2
  nn2 = ((2*ps + 1) * (2*m2+1) - 1)/2
  nn3 = ((2*ps + 1) * (2*m3+1) - 1)/2
  ntotal = o*(2*nn1+1)*(2*nn2+1)*(2*nn3+1)-1*o

  !
  ! cubic expansion
  !m1 = ((2*nn1+1)/(2*ps+1) - 1)/2
  !m2 = ((2*nn2+1)/(2*ps+1) - 1)/2
  !m3 = ((2*nn3+1)/(2*ps+1) - 1)/2
  if ( m1.eq.0 .and. m2.eq.0  .and. m3.eq.0 ) then
    call layer_dirs_tric(ps,x,y,z,ua,ub,uc,dirs)
    return
  end if

  !
  ! cuboid expansion, set up index begin ns(1:np+1)
  do i = 1, ps
    k = ps+1-i
    nt(i) = o*(2*m1+1)*(2*m2+1)*(2*m3+1)*(2*k+1)**3 - &
          & o*(2*m1+1)*(2*m2+1)*(2*m3+1)*(2*k-1)**3
  end do
  nt(ps+1) = o*(2*m1+1)*(2*m2+1)*(2*m3+1) - 1

  nc(1) = o*0
  do i = 2, ps+1
    nc(i) = sum(nt(1:i-1))
  end do
  if (nc(ps+1)+nt(ps+1).ne.ntotal ) stop 'ns + nt .ne. ntotal error'

  !
  ! assign indx,indy,indz(:)
  do i = -nn1, nn1
    if ( abs(i).le.m1 ) then
      ix = 0
    else
      ix = int(( dble(2*abs(i)-1)/dble(2*m1+1)-1.0d0)/2.0d0)+1
    end if
    do j = -nn2, nn2
      if ( abs(j).le.m2 ) then
        iy = 0
      else
        iy = int(( dble(2*abs(j)-1)/dble(2*m2+1)-1.0d0)/2.0d0)+1
      end if
      do k = -nn3, nn3
        if ( abs(k).le.m3 ) then
          iz = 0
        else
          iz = int(( dble(2*abs(k)-1)/dble(2*m3+1)-1.0d0)/2.0d0)+1
        end if

        if ( (i.ne.0) .or. (j.ne.0) .or. (k.ne.0) ) then
          is = ps + 1 - max(ix,iy,iz)
          nc(is)  = nc(is) + o*1
          indx(nc(is)) = i
          indy(nc(is)) = j
          indz(nc(is)) = k
        end if
      end do
    end do
  end do


  ! check and debug
  !write(*,*) "nc(ps+1),ntotal=", nc(ps+1), ntotal
  do i = 1, ps+1
    if ( nc(i) .ne. sum(nt(1:i)) ) then
      write(*,*) "i=", i, "nc(i)=", nc(i), "sum(nt(1:i))=", sum(nt(1:i))
    end if
  end do

  !
  !  check first index
  !do i = 1, 10
  !  write(*,*) "indx(i),indy,indz=", indx(i),indy(i),indz(i)
  !end do
  dirs = 0.0d0
  do io = 1, ntotal
    ix = indx(io); iy = indy(io); iz = indz(io)
    rx = x + dble(ix)*ua(1) + dble(iy)*ub(1) + dble(iz)*uc(1)
    ry = y + dble(ix)*ua(2) + dble(iy)*ub(2) + dble(iz)*uc(2)
    rz = z + dble(ix)*ua(3) + dble(iy)*ub(3) + dble(iz)*uc(3)
    rsq = sqrt(rx**2 + ry**2 + rz**2)
    rx0 = dble(ix)*ua(1) + dble(iy)*ub(1) + dble(iz)*uc(1)
    ry0 = dble(ix)*ua(2) + dble(iy)*ub(2) + dble(iz)*uc(2)
    rz0 = dble(ix)*ua(3) + dble(iy)*ub(3) + dble(iz)*uc(3)
    sqn = sqrt(rx0**2 + ry0**2 + rz0**2)
    dirs = dirs + 1.0d0/rsq - 1.0d0/sqn
  end do
  dirs = dirs + 1.0d0/sqrt(x**2+y**2+z**2)
  return

end subroutine layer_cuboid_tric
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
